import { createSlice } from "@reduxjs/toolkit";

const authSlice = createSlice({
    name: 'auth',
    initialState: {
        isAUthenticated: true,
        user: null,
        error: null
    },
    reducers : {
        loginSuccess: (state,action)=>{
            state.isAUthenticated = true
            state.user = action.payload
            state.error = null
        },
        loginFailure: (state,action)=>{
            state.isAUthenticated = false
            state.user = null
            state.error = action.payload
        },
        logout: (state,action)=>{
            state.isAUthenticated = null
            state.user = null
            state.error = null

        }
    }
})

export const {loginSuccess,loginFailure,logout} = authSlice.actions
export default authSlice.reducer