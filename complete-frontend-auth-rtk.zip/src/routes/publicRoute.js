import React from 'react'
import Login from '../pages/Login'
import { Navigate } from 'react-router'

const publicRoute = (checkAuth) => {


  return [
    { path: "/login", element: checkAuth() ? <Navigate to={'/'}/> : <Login/> },
    { path: "*", element: <Navigate to={'/login'}/> },
  ];

};


export default publicRoute