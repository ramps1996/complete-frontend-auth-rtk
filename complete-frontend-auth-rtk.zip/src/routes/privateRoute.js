import React from 'react'
import Layout from '../layouts/Layout'
import Setting from '../pages/Setting'
import { Navigate } from 'react-router'
import Home from '../pages/Home'


const privateRoute = () => {
  return {
    path: "",
    element :<Layout/>,
    children: [
        {path:"/",element:<Home/>},
        {path:"/settings",element:<Setting/>},
        {path:"*", element:<Navigate to={'/'}/>},

    ]
  }
}

export default privateRoute