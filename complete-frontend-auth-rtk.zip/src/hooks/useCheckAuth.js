import { useSelector } from 'react-redux'

const useCheckAuth = () => {
  const { isAUthenticated } = useSelector(state => state.auth)

  return isAUthenticated
}

export default useCheckAuth