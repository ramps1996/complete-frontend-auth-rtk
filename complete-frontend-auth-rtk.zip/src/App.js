import React from 'react'
import { RouterProvider, createBrowserRouter } from 'react-router-dom'
import privateRoute from './routes/privateRoute'
import publicRoute from './routes/publicRoute'
import useCheckAuth from './hooks/useCheckAuth'



const App = () => {

    const router = createBrowserRouter([
        useCheckAuth()?privateRoute():{},
        ...publicRoute(useCheckAuth)
        ])

    return <RouterProvider router={router}/>
}

export default App